package br.com.gestao_hospitalar.paciente_service.dto;

public class StripeSessionDTO {

  private String sessionId;

  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }
}

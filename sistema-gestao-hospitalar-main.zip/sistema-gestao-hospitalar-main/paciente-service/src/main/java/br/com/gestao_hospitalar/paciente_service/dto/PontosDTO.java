package br.com.gestao_hospitalar.paciente_service.dto;

import lombok.Data;

@Data
public class PontosDTO {
    private int quantidade;
}
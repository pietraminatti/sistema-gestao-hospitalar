package br.com.gestao_hospitalar.paciente_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PacienteServiceApp {
    public static void main(String[] args) {
        SpringApplication.run(PacienteServiceApp.class, args);
    }
}
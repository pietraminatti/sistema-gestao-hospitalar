package br.com.gestao_hospitalar.paciente_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacienteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

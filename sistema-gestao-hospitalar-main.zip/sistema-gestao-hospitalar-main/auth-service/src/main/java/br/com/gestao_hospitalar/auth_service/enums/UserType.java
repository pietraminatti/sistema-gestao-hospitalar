package br.com.gestao_hospitalar.auth_service.enums;

public enum UserType {
  PACIENTE,
  FUNCIONARIO,
  ADMIN,
}

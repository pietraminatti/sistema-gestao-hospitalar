package br.com.gestao_hospitalar.consulta_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsultaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsultaServiceApplication.class, args);
	}

}

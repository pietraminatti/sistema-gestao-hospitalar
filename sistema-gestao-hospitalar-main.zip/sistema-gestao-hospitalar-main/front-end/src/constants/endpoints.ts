export const ENDPOINTS = {};

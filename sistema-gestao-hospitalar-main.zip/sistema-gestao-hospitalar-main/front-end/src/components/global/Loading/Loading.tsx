import { CircularProgress } from "@mui/material";

export const Loading = () => {
  return (
    <div>
      <CircularProgress />
    </div>
  );
};

import { AppRoutes } from "./router/AppRoutes.tsx";

function App() {
  return <AppRoutes />;
}

export default App;
